const btnSearch = document.getElementById("btn-search");
const inputSearch = document.getElementById("input-search");

// Toggle click btnSearch
btnSearch.addEventListener("click", function () {
  inputSearch.classList.toggle("show");
});
